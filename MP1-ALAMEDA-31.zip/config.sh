INPUT=inputs.txt
EXPECTED=expected.txt
OUTPUT=target/tests/output.txt

## Defaults value for flags ##
COMPILE=1
HELP=0
TEST=0
CLEAN=0
GETVALUE=0
